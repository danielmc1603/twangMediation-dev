#' @keywords propensity score
#' @import lattice
#' @import latticeExtra
#' @import survey
#' @importFrom graphics par boxplot
#' @importFrom stats aggregate as.formula glm na.omit na.pass predict qnorm update
"_PACKAGE"
